import 'angular';
import 'jquery';
import 'angular-ui-router';
import 'angular-sanitize';
import 'meetyou-angular-ui';
