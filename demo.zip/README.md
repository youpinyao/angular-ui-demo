# 安装依赖
npm i
# 开发调试
npm run start
# 构建
npm run build
